# Sample functions script 

addtwo <- function(x) x+2

